function setup() {
  createCanvas(300, 500);
}

function draw() {
  background(220);
  circle (150, 200, 110);
  fill (247, 235, 220);
  circle (120, 185, 10);
  circle (170, 185, 10);
  line (95, 210, 90, 300);
  line (205, 210, 200, 300);
  line (175, 250, 175, 285);
  line (135, 252, 135, 285);
  point (120, 185);
  point (170, 185);
  triangle (140,220,145,185,150,220);
  rect (125, 287, 58, 150);
  text ('Dahlia Pettitt',20,30);
}